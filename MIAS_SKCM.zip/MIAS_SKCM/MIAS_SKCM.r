##################################################################################
### Installation 
##################################################################################
# 1. After unzipping the "MIAS_SKCM.zip", navigate to the extension folder, "MIAS_SKCM", and set it 
#	   as the working directory
# 2. Install the required R packages: FusionPathway, GSVA, and e1071
# 3. Run the following script using your gene expression data
# 4. Please email questions to Chia-Chin Wu, cwu9@mdanderson.org



##################################################################################
### Example: calcluate the MIAS score
##################################################################################
## Navigate to the extension folder, "MIAS_SKCM"
## setwd("the extension folder, MIAS_SKCM")

## load the require R packages and scripts
library(GSVA)
source("MIAS_functions.r")

## load the selected SKCM signature genes for calculating MIAS scores 
filein="./data/Table.S6_Immune_positive signature.xls"
DataM1 <- read.table(filein,sep="\t",header=T, quote="")
Signatures_M<-NULL
Signatures_M[[1]]=as.character(DataM1[[1]])

## load the gene expressio data of the melanoma patient samples for response prediction. 
## The gene expression value should be calucated as transcripts per million (TPM) that 
## normalize counts for library size and gene length. 
## Here, an example dataset (complied from Riaz, et al 2017) was loaded. This data set 
## contain a gene expression matrix od patient samples (DataM_EX), patient response (Response)
## , biopsy timepoint (PreOn).
load("./data/Example.Data_Riaz.2017.RData")

## The MIAS scores of samples can be calculated using the signature (Signatures_M) and 
## the gene expresison matrix (DataM_EX)
MIAS_Score<-MIAS.Score.GSVA(DataM_EX,Signatures_M)
MIAS_Score


## Quantify the correlation between the MIAS score and patient response using the AUC value 
## of the ROC curve and Wilcox test (only appicable to samples with response data)
outcome=rep(1,length(MIAS_Score))
outcome[which(Response=="NR")]=0
ROC<-ROCF(outcome,MIAS_Score)
score.pos<-MIAS_Score[which(Response=="R")]
score.neg<-MIAS_Score[which(Response=="NR")]
Wilcox.pval<-as.numeric(wilcox.test(score.pos, score.neg, alternative="greater")$p.value)
print(ROC$AUC)
print(Wilcox.pval)



##################################################################################
### Example: Response prediciton using MIAS.IMPRES predictors
##################################################################################
## Navigate to the folder, "MIAS_SKCM"
## setwd("the extension folder, MIAS_SKCM")


## Load the require R packages
library(e1071) #svm
library(GSVA)
source("MIAS_functions.r")


## Load the data file containing the 2 pre-trained predictors: MIAS.IMPRES.Classifier_Pre
## , and MIAS.IMPRES.Classifier_On.
load("./data/Response.Predictors_PD1_SKCM.RData")

## Load the gene expressio data of the melanoma patient samples for response prediction. 
## Here, an example dataset (Riaz, et al 2017) was loaded.
load("./data/Example.Data_Riaz.2017.RData")

## Seperate data of pre- and on-treatment samples
DataM_EX.Pre<-DataM_EX[,which(PreOn=="Pre")]
Response.Pre<-Response[which(PreOn=="Pre")]
DataM_EX.On<-DataM_EX[,which(PreOn=="On")]
Response.On<-Response[which(PreOn=="On")]

## Load the selected SKCM signature genes for calculating MIAS scores.
filein="./data/Table.S6_Immune_positive signature.xls"
DataM1 <- read.table(filein,sep="\t",header=T, quote="")
Signatures_M<-NULL
Signatures_M[[1]]=as.character(DataM1[[1]])

## Calculate the MIAS and IMPRES Scores of the pre- and on-treatment samples
MIAS_Score.Pre<-MIAS.Score.GSVA(DataM_EX.Pre,Signatures_M)
IMPRES_Score.Pre<-IMPRES.Score(DataM_EX.Pre)
MIAS_Score.On<-MIAS.Score.GSVA(DataM_EX.On,Signatures_M)
IMPRES_Score.On<-IMPRES.Score(DataM_EX.On)

## Do the response prediction of the on-treatment samples using the on-treatment predictor
data_set.On<-data.frame(MIAS=MIAS_Score.On,IMPRES=IMPRES_Score.On,Response=Response.On)
prediction.On = predict(MIAS.IMPRES.Classifier_On, newdata = data_set.On[-3], probability =T)

## Print out the predicted patient response
print (prediction.On)

## We can also do the response prediction to the pre-treatment samples using the 
## pre-treatment predictor, MIAS.IMPRES.Classifier_Pre (the script was not listed here). 












